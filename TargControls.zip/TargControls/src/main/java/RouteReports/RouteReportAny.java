package RouteReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class RouteReportAny {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","D:\\chrome\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.get("https://dev.targcontrol.com/login");

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.name("username")).click();
        driver.findElement(By.name("username")).sendKeys("dimos4611not@mail.ru");
        driver.findElement(By.name("password")).click();
        driver.findElement(By.name("password")).sendKeys("111111");
        driver.findElement(By.id("login-btn")).click();

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.xpath("//span[contains(.,'Маршруты')]")).click();

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.cssSelector(".d-inline-block:nth-child(1) .dx-dropdowneditor-icon")).click();

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.cssSelector(".dx-icon-chevronleft")).click();

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.xpath("//div[6]/div/div/div/div/div/div/table/tbody/tr/td[2]")).click();

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.xpath("//button[contains(.,'Построить отчет')]")).click();

        TimeUnit.MILLISECONDS.sleep(20000);

        driver.quit();
    }
}
