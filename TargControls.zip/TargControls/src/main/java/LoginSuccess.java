import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Award {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "D:\\chrome\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        driver.get("https://login.idelic.software/login?state=hKFo2SA2ZXFVS1phQTM2dDdKNi01X0lMeWtybFdCODI5anpEb6FupWxvZ2luo3RpZNkgSWZUeW9DT3dycU9VNnoxRnBNOVlyQkxwcWhiVWxPcS2jY2lk2SBRTmZhaFZ2Q1dWMjcxRm42QXNuUVF4cVhtdmdhMmJTRA&client=QNfahVvCWV271Fn6AsnQQxqXmvga2bSD&protocol=oauth2&audience=https%3A%2F%2Flogin-backend-api.idelic.software&redirect_uri=https%3A%2F%2Flogin-master.testing.idelic.software%2Fcompanies&scope=openid%20profile%20email&response_type=code&response_mode=query&nonce=VzJzLVlXLmV5N0psa25CbFV3bWZQU2p6S1V3TzBPZ25wbEt2a1IxV3RHZw%3D%3D&code_challenge=a5TFNWNQmb0-1bhA_MZDoemDBUEOoGmOMxD6umYEruI&code_challenge_method=S256&auth0Client=eyJuYW1lIjoiYXV0aDAtc3BhLWpzIiwidmVyc2lvbiI6IjEuMTUuMCJ9");

        TimeUnit.MILLISECONDS.sleep(10000);

        driver.findElement(By.xpath("//input[@id='email']")).click();
        driver.findElement(By.xpath("//input[@id='email']")).sendKeys("testing+admin@idelic.com");
        driver.findElement(By.xpath("//input[@id='password']")).click();
        driver.findElement(By.xpath("//input[@id='password']")).sendKeys("wb7>eCN]yIb.O?IM.Eo{");
        driver.findElement(By.xpath("//button[@id='btn-login']")).click();

        TimeUnit.MILLISECONDS.sleep(10000);

        driver.findElement(By.id("TextField13")).click();
        driver.findElement(By.id("TextField13")).sendKeys("saf-master");
        driver.findElement(By.xpath("//div[@id='root']/div/div/div/div[2]/div/div[2]/a/div/div/span/span")).click();

        TimeUnit.MILLISECONDS.sleep(10000);

        driver.quit();
    }
}
