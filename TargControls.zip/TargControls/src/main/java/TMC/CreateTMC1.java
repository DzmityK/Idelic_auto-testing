package TMC;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class CreateTMC1 {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "D:\\chrome\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.get("https://dev.targcontrol.com/login");

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.name("username")).click();
        driver.findElement(By.name("username")).sendKeys("info@targcontrol.com");
        driver.findElement(By.name("password")).click();
        driver.findElement(By.name("password")).sendKeys("password");
        driver.findElement(By.id("login-btn")).click();

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.xpath("//a[contains(@href, '/inventory')]")).click();

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.xpath("//div[@id='inventoryAdd']/button")).click();

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.xpath("//a[contains(text(),'ТМЦ')]")).click();

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.xpath("//input[@name='inventoryItemName']")).click();
        driver.findElement(By.xpath("//input[@name='inventoryItemName']")).sendKeys("mar");
        driver.findElement(By.xpath("//textarea[@name='description']")).click();
        driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys("asfasf");
        driver.findElement(By.xpath("//button[contains(.,'Сохранить')]")).click();

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.quit();
    }
}
