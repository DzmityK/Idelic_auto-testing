package LoginRegistrForgPassw;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class ForgotPassword {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "D:\\chrome\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://dev.targcontrol.com/login");
        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.id("forgot-password-btn")).click();

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.xpath("//input[@name='emailRecovery']")).click();
        driver.findElement(By.xpath("//input[@name='emailRecovery']")).sendKeys("dimos4611not@mail.ru");
        driver.findElement(By.cssSelector(".primary-button")).click();

        TimeUnit.MILLISECONDS.sleep(3000);
        driver.quit();
    }
}
