package LoginRegistrForgPassw;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class RegistrationOk {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "D:\\chrome\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        driver.get("https://dev.targcontrol.com/login");

        TimeUnit.MILLISECONDS.sleep(4000);

        driver.findElement(By.cssSelector(".primary-link")).click();

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.linkText("сотрудник")).click();

        TimeUnit.MILLISECONDS.sleep(3000);

        driver.findElement(By.xpath("//input[@name='email']")).click();
        driver.findElement(By.xpath("//input[@name='email']")).sendKeys("sg@mail.ru");
        driver.findElement(By.xpath("//button[contains(.,'Далее')]")).click();

        TimeUnit.MILLISECONDS.sleep(5000);

        driver.quit();

    }
}
